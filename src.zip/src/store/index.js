import Vue from 'vue'
import Vuex from 'vuex'

import menu from './modules/menu'
Vue.use(Vuex)

let store = new Vuex.Store({
    state:{},
    getters:{},
    mutations:{},
    actions:{},
    modules:{
        menu
    }
})

export default store