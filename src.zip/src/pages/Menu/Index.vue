<template>
    <el-card>
      <el-button @click="add" type="primary" icon="el-icon-circle-plus-outline"
        >新增</el-button
      >
      <el-divider></el-divider>
      <List/>

      <Model :info="info"/>
    </el-card>
</template>

<script>
import List from "./List";
import Model from './Model'
export default {
    
  data() {
    return {
        info:{
            isShow:false,
            isAdd:true
        }
    };
  },
  created() {

  },
  computed: {

  },
  methods: {
      add(){
          this.info.isShow = true
          this.info.isAdd = true
      }
  },
  components: {
    List,Model
  },
};
</script>
<style scoped>
</style>

