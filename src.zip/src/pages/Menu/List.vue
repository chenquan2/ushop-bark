<template>
  <el-table
    :data="menuList"
    style="width: 100%; margin-bottom: 20px"
    row-key="id"
    default-expand-all
    :tree-props="{ children: 'children', hasChildren: 'hasChildren' }"
  >
    <el-table-column prop="id" label="ID" width="180"> </el-table-column>
    <el-table-column prop="title" label="菜单管理" width="180">
    </el-table-column>
    <el-table-column prop="icon" label="图标" width="180">
      <template slot-scope="scopt">
        <i :class="scopt.row.icon"></i>
      </template>
    </el-table-column>
    <el-table-column prop="url" label="地址"> </el-table-column>
    <el-table-column prop="status" label="状态">
      <template slot-scope="scope">
        <el-tag type="success" v-if="scope.row.status == 1">正常</el-tag>
        <el-tag type="warniing" v-else>禁用</el-tag>
      </template>
    </el-table-column>
    <el-table-column label="操作">
      <template slot-scope="abc">
        <el-button
          class="color"
          type="primary"
          icon="el-icon-edit"
          circle
          @click="edit(abc)"
        ></el-button>
        <el-button
          @click="del(abc.row.id)"
          type="danger"
          icon="el-icon-delete"
          circle
        ></el-button>
      </template>
    </el-table-column>
  </el-table>
</template>

<script>
import { mapState, mapActions } from "vuex";
import { delMenu } from "../../request/menu";
export default {
  data() {
    return {};
  },
  created() {
    this.setMenuListAction();
  },
  computed: {
    ...mapState({ menuList: (state) => state.menu.menuList }),
  },
  methods: {
    ...mapActions("menu", ["setMenuListAction"]),
    edit(val) {
      console.log(val);
    },
    del(id) {
      this.$confirm("此操作将永久删除该文件, 是否继续?", "提示", {
        confirmButtonText: "确定",
        cancelButtonText: "取消",
        type: "warning",
      })
        .then(() => {
          delMenu(id).then((res) => {
            if (res.code === 200) {
              this.$message({
                type: "success",
                message: res.msg,
              });
              this.setMenuListAction();
            } else {
              this.$message({
                type: "error",
                message: res.msg,
              });
            }
          });
        })
        .catch(() => {
          this.$message({
            type: "info",
            message: "已取消删除",
          });
        });
    },
  },
  components: {},
};
</script>
<style scoped>
.color {
  background-color: #6bc03d;
}
</style>
