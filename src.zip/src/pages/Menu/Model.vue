<template>
  <el-dialog @close="close" title="新增" :visible.sync="info.isShow">
    <el-form :model="form">
      <el-form-item label="类型" :label-width="formLabelWidth">
        <el-radio-group v-model="form.type">
          <el-radio :label="1">目录</el-radio>
          <el-radio :label="2">菜单</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="名称" :label-width="formLabelWidth">
        <el-input v-model="form.title" autocomplete="off"></el-input>
      </el-form-item>
      <el-form-item label="图标" :label-width="formLabelWidth">
        <el-input v-model="form.icon" autocomplete="off"></el-input>
      </el-form-item>
      <el-form-item label="状态" :label-width="formLabelWidth">
        <el-radio-group v-model="form.status">
          <el-radio :label="1">正常</el-radio>
          <el-radio :label="2">禁用</el-radio>
        </el-radio-group>
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="info.isShow = false">取 消</el-button>
      <el-button type="primary" @click="submit">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
import { addMenu } from "../../request/menu";
import { mapActions } from "vuex";
export default {
  props: ["info"],
  data() {
    return {
      dialogFormVisible: false,
      form: {
        pid: 0,
        title: "",
        icon: "",
        url: "",
        type: 1,
        status: 1,
      },
      formLabelWidth: "80px",
    };
  },
  created() {},
  methods: {
    ...mapActions("menu", ["setMenuListAction"]),
    submit() {
      addMenu(this.form).then((res) => {
        console.log(res);
        if (res.code === 200) {
          this.$message({
            message: res.msg,
            type: "success",
          });
          this.info.isShow = false;
          this.setMenuListAction();
        }
      });
    },
    close(){
        this.form ={
        pid: 0,
        title: "",
        icon: "",
        url: "",
        type: 1,
        status: 1,
        }
    }
  },
  components: {},
};
</script>
<style scoped>
</style>
