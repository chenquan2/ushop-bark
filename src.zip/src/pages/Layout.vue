<template>
  <el-container>
    <el-aside :width="isCollapse ? '64px' : '226px'">
      <h3>小u商城后台</h3>
      <el-menu
        :default-active="$route.path"
        class="el-menu-vertical-demo"
        background-color="#333"
        text-color="#fff"
        active-text-color="#ffd04b"
        router
        :collapse="isCollapse"
        :collapse-transition="false"
      >
        <el-menu-item index="/home">
          <i class="el-icon-menu"></i>
          <span slot="title">管理中心</span>
        </el-menu-item>
        <el-submenu index="2">
          <template slot="title">
            <i class="el-icon-setting"></i>
            <span>系统设置</span>
          </template>
          <el-menu-item index="/menu">
            <span slot="title">菜单管理</span>
          </el-menu-item>
          <el-menu-item index="4">
            <span slot="title">角色管理</span>
          </el-menu-item>
          <el-menu-item index="5">
            <span slot="title">管理员管理</span>
          </el-menu-item>
        </el-submenu>
        <el-submenu index="3">
          <template slot="title">
            <i class="el-icon-s-goods"></i>
            <span>商城管理</span>
          </template>
          <el-menu-item index="/cate">
            <span slot="title">分类管理</span>
          </el-menu-item>
          <el-menu-item index="/specs">
            <span slot="title">规格管理</span>
          </el-menu-item>
          <el-menu-item index="/goods">
            <span slot="title">商品管理</span>
          </el-menu-item>
        </el-submenu>
      </el-menu>
    </el-aside>
    <el-container>
      <el-header>
        <div class="left">
          <el-button
            class="btn"
            type="primary"
            icon="el-icon-s-fold"
            size="mini"
            @click="isCollapse = !isCollapse"
          ></el-button>
          <div class="Breadcrumb">
            <el-breadcrumb separator="/">
              <el-breadcrumb-item :to="{ path: '/home' }">管理中心</el-breadcrumb-item>
              <el-breadcrumb-item><a href="/">菜单管理</a></el-breadcrumb-item>
            </el-breadcrumb>
          </div>
        </div>

        <div class="right">
          <el-dropdown>
            <span class="el-dropdown-link">
              admin<i class="el-icon-arrow-down el-icon--right"></i>
            </span>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item icon="el-icon-user">个人中心</el-dropdown-item>
              <el-dropdown-item icon="el-icon-full-screen"
                >全屏预览</el-dropdown-item
              >
              <el-dropdown-item icon="el-icon-switch-button">
                <span @click="quit"> 安全退出</span>
              </el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </div>
      </el-header>
      <el-main>
        <router-view></router-view>
      </el-main>
    </el-container>
  </el-container>
</template>

<script>
export default {
  data() {
    return {
      isCollapse: false,
    };
  },
  methods: {
    quit() {
      this.$message({
        message: "退出成功",
        type: "success",
      });
      localStorage.removeItem("userInfo");
      this.$router.push("/login");
    },
  },
};
</script>
<style scoped>
.el-header {
  background-color: #fff;
  line-height: 60px;
  display: flex;
  justify-content: space-between;
  box-shadow: 0 0 5px #333;
  z-index: 1;
}

.el-aside {
  background-color: #333;
  transition: all 0.5s ease;
}
.el-aside h3 {
  height: 60px;
  line-height: 60px;
  text-align: center;
  background-color: #444;
  color: #fff;
  letter-spacing: 5px;
  white-space: nowrap;
}
.el-main {
  background-color: #e9eef3;
}

.el-container {
  height: 100vh;
}
.el-menu {
  border: 0;
}
.btn {
  font-size: 15px;
}
.Breadcrumb{
    margin-left: 10px;
    display: inline-block;
}
</style>
