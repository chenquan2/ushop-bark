<template>
<div>
    <h1>管理中心</h1>
</div>
</template>

<script>

export default{
data(){
return{}
},
created(){},
methods:{},
components:{},
}
</script>
<style scoped>

</style>
