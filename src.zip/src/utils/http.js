import axios from 'axios'
import Vue from 'vue'

import router from '../router'
axios.defaults.baseURL = 'http://localhost:3000/api'

axios.interceptors.request.use(function(config){
    let userInfo = JSON.parse(localStorage.getItem('userInfo')|| '{}')
    config.headers.authorization = userInfo.token
    return config
})

axios.interceptors.response.use(function(response){
    if(response.data.code ===403){
        router.push('/login')
    }
    return response.data
})

Vue.prototype.$http = axios

export default axios