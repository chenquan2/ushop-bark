import Vue from 'vue'
import Router from 'vue-router'
let Layout = ()=>import('../pages/Layout')
let Login = ()=>import('../pages/Login')
let Menu = ()=>import('../pages/Menu/Index')
let Home = ()=>import('../pages/Home/Index')

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      component: Layout,
      redirect:'/home',
      children:[
        {
          path:'/home',
          component:Home
        },
        {
          path:'/menu',
          component:Menu
        }
      ]
    },
    {
      path: '/login',
      component: Login
    }
  ]
})
