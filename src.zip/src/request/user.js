import axios from '../utils/http'

export function userLogin(data){
    let res = axios.post('/userlogin',data)
    return res
}