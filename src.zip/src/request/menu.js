import axios from '../utils/http'

export function menuList(){
    let res = axios.get('/menulist?istree=1')
    return res
}

export function addMenu(data){
    let res = axios.post('/menuadd',data)
    return res
}

export function delMenu(id){
    let res = axios.post('/menudelete',{id:id})
    return res
}